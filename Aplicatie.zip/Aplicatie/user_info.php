<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplicatie</title>
    <link rel="stylesheet" href="./css/style.css">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$user = $_POST['user'];
$nume = $_POST['nume'];
$telefon = $_POST['telefon'];
$firstday = $_POST['firstday'];
$lastday = $_POST['lastday'];
$sql = "INSERT INTO rezervari (username, nume, telefon, firstday, lastday)
VALUES ('$user', '$nume', '$telefon', '$firstday', '$lastday')";
if ($conn->query($sql) === TRUE) {
  // echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
<br>
<button style="margin-left:30px"><a href="login.html" style="color:white; text-decoration:none;">Logout</a></button>
<button style="margin-left:30px" onclick="window.history.back()">Back</button><br><br>
<h4 style="margin-left:30px">Rezervările tale:</h4>

<?php
$sql = "SELECT username, nume, telefon, firstday, lastday FROM rezervari WHERE username='$user'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    ?>
    <div style="margin-left:30px">
    <?php
    echo "Nume: " . $row["nume"] . "<br>" ."Telefon: " . $telefon . "<br>" . "Data:" . $firstday . "-" . "$lastday" . "<br>" . "<br>";
    ?>
    </div>
    <?php
  }
} else {
  echo "0 results";
}
?>




<script src="javascript.js"></script>
<!-- Bootstrap 5 scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>